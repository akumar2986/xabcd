﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tutorial.Entities
{
    public class TutorialTopic
    {
        public int TutorialId { get; set; }
        public string Name { get; set; }
        public int TotalTopics { get; set; }
        public List<TutorialTopic> TutorialTopics { get; set; }
    }
}
