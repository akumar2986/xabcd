﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tutorial.Entities
{
    public class Question
    {
        public long QuestionId { get; set; }
        public string Description { get; set; }
        public string CustomerCode { get; set; }
        public long QuestionTypeID { get; set; }
        public long TopicId { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public System.DateTime CreatedDateTime { get; set; }
        public System.DateTime ModifiedDateTime { get; set; }

        public List<QuestOption> QuestOptions { get; set; }
    }

   
}
