﻿var app = angular.module('TopicApp', []);

var topicservice = new TopicService();

app.controller('TopicCtrl', ['$scope', '$http', function ($scope, $http) {

    topicservice.GetTopics($http, function (data) {
        $scope.topics = response.data.topics;
        alert(data);
        angular.forEach($scope.topics, function (obj) {
            obj["showEdit"] = true;
        })
    });

    //$http({
    //    method: 'POST',
    //    url: 'GetTopics'
    //})
    //.then(function (response) {
    //    console.log(response);
    //    $scope.topics = response.data.topics;

    //    angular.forEach($scope.topics, function (obj) {
    //        obj["showEdit"] = true;
    //    })

    //}, function (error) {
    //    console.log(error);
    //});

}]);