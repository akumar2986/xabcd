﻿var TopicService = function () {
    this.GetTopics = function ($http,successCallBack, errorCallBack) {
        $http.get("/Topic/GetTopics").success(function (data) {
            successCallBack(data);
        });
    }    
}

