﻿using IndiaTutorial.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Tutorial.BLL;

namespace IndiaTutorial.Controllers
{
    public class DotNetTutorialController : Controller
    {
        //
        // GET: /CSharp/

        public ActionResult WCFTutorial()
        {
            DotNetTutorial tutorialbll = new DotNetTutorial();
            //var datacontent = tutorialbll.GetContentText(1);
            ContentModel model = new ContentModel();
           // model.ContentId = datacontent.ContentId;
           // model.ContentData = datacontent.Content;
            model.ContentData = " बेनीमाधव सिंह गौरीपुर गाँव के जमींदार और नम्बरदार थे। उनके पितामह किसी समय बड़े धन-धान्य संपन्न थे।" +
            "गाँव का पक्का तालाब और मंदिर जिनकी अब मरम्मत भी मुश्किल थी, उन्हीं की कीर्ति-स्तंभ थे। कहते हैं, इस दरवाजे पर हाथी झूमता था, अब उसकी जगह एक बूढ़ी भैंस थी," +
            "जिसके शरीर में अस्थि-पंजर के सिवा और कुछ शेष न रहा था;<br/> पर दूध शायद बहुत देती थी; क्योंकि एक न एक आदमी हाँड़ी लिये उसके सिर पर सवार ही रहता था। बेनीमाधव सिंह अपनी आधी से" +
            "अधिक संपत्ति वकीलों को भेंट कर चुके थे। उनकी वर्तमान आय एक हजार रुपये वार्षिक से अधिक न थी। ठाकुर साहब के दो बेटे थे। बड़े का नाम श्रीकंठ सिंह था। उसने बहुत दिनों के परिश्रम और उद्योग " +
            "के बाद बी. ए. की डिग्री प्राप्त की थी। अब एक दफ्तर में नौकर था। छोटा लड़का लालबिहारी सिंह दोहरे बदन का, सजीला जवान था। भरा हुआ मुखड़ा, चौड़ी छाती। भैंस का दो सेर ताजा दूध वह उठ" +
            "कर सबेरे पी जाता था। श्रीकंठ सिंह की दशा बिलकुल विपरीत थी। इन नेत्रप्रिय गुणों को उन्होंने बी. ए.-इन्हीं दो अक्षरों पर न्योछावर कर दिया था। इन दो अक्षरों ने उनके शरीर को निर्बल और चेहरे को " +
            "कांतिहीन बना दिया था। इसी से वैद्यक ग्रंथों पर उनका विशेष प्रेम था। आयुर्वैदिक औषधियों पर उनका अधिक विश्वास था। शाम-सबेरे से उनके कमरे से प्रायः खरल की सुरीली कर्णमधुर ध्वनि सुनायी दिया" +
            "करती थी। लाहौर और कलकत्ते के वैद्यों से बड़ी लिखा-पढ़ी रहती थी।";
            return View(model);
        }
        public ActionResult WPFTutorial()
        {
            return View();
        }
        public ActionResult MVCTutorial()
        {
            return View();
        }

        public ActionResult CSharpBasicTutorial()
        {
            return View();
        }

        public ActionResult SilverLightTutorial()
        {
            return View();
        }

    }
}
