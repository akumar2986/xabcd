﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using IndiaTutorial.Models;

namespace IndiaTutorial.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }

        [ChildActionOnly]
        public PartialViewResult LoadTutorialMenu()
        {
            Tutorial.BLL.TutorialTopic article = new Tutorial.BLL.TutorialTopic();
            List<Tutorial.Entities.TutorialTopic> articlentities = article.GetArticlesByArticleId(0);
            List<BaseViewModel> articlelist = new List<BaseViewModel>();
            foreach (var item in articlentities)
            {
                TutorialModel articlemodel = new TutorialModel();
                articlemodel.TopicId = item.TutorialId;
                articlemodel.TopicName = item.Name;
                articlemodel.TutorialModels = new List<TutorialModel>();
                foreach (var subarticle in item.TutorialTopics)
                {
                    TutorialModel model = new TutorialModel();
                    model.TopicId = subarticle.TutorialId;
                    model.TopicName = subarticle.Name;
                    articlemodel.TutorialModels.Add(model);
                }
                articlelist.Add(articlemodel);
            }
            return PartialView("_AllTutorialPartial", articlelist);
        }
    }
}
