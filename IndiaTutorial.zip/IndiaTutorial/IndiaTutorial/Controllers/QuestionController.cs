﻿using IndiaTutorial.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IndiaTutorial.Controllers
{
    public class QuestionController : Controller
    {
        //
        // GET: /Question/

        public ActionResult Index()
        {
            if (Request.IsAjaxRequest())
                return View(); // Return view with no master.
            else
            {
                Tutorial.BLL.Question question = new Tutorial.BLL.Question();
                List<Tutorial.Entities.Question> questionlist = question.GetQuestionsByTopicId(1);
                List<QuestionModel> questmodels = new List<QuestionModel>();

                foreach (var item in questionlist)
                {
                    QuestionModel questmodel = new QuestionModel();
                    questmodel.TopicId = item.TopicId;
                    questmodel.Description = item.Description;
                    questmodel.QuestionOptionModels = new List<QuestionOptionModel>();
                    foreach (var options in item.QuestOptions)
                    {
                        QuestionOptionModel questoption = new QuestionOptionModel();
                        questoption.OptionId = options.OptionId;
                        questoption.OptionDesc = options.OptionDesc;
                        questmodel.QuestionOptionModels.Add(questoption);
                    }
                    questmodels.Add(questmodel);
                }
                return View("Index", "_Layout", questmodels); // Return view with master.
            }           

        }

        public ActionResult EditQuestion(int id)
        {
            QuestionModel brandModel = new QuestionModel();
            return PartialView("MCQPartial", brandModel);
        }

        public ActionResult MCQPartial(FormCollection collection)
        {
            return null;
        }

    }
}
