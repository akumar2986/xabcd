﻿using IndiaTutorial.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DealNetwork.Controllers
{
    public class TopicController : Controller
    {
       // ITopicBll iTopicBll;
       // IUnitOfWork unitOfwork;
        public TopicController()
        {
            //unitOfwork = new UnitOfWork();

            //iTopicBll = new TopicBll(unitOfwork);
        }
        // GET: Topic
        public ActionResult Index()
        {
            try
            {
                List<TopicModel> models = new List<TopicModel>();
                return View(models);
            }
            catch (Exception ex)
            {
                throw ex;
            } 
        }

        //public JsonResult GetEmployees()
        //{+
        //    List<Employee> empList = new List<Employee>();

        //    Employee emp = new Employee { FirstName = "James", LastName = "Bond", Country = "Germany" };
        //    empList.Add(emp);

        //    emp = new Employee { FirstName = "Roy", LastName = "Agasthyan", Country = "United States" };
        //    empList.Add(emp);

        //    return Json(new { employees = empList });
        //}

        public JsonResult GetTopics()
        {
            List<TopicModel> models = new List<TopicModel>();
            TopicModel topic = new TopicModel { TopicId=1, TopicName = "James",IsDeleted=false,CreatedDateTime=DateTime.Now,CreatedBy="anil"};
            models.Add(topic);
            topic = new TopicModel { TopicId = 2, TopicName = "James34" };
            models.Add(topic);
            return Json(new { topics = models });
        }

        //public JsonResult GetTopics(DataTablesParam param)
        //{
        //    try
        //    {

        //        List<TopicModel> TopicModel = iTopicBll.GetTopics();
        //        IEnumerable<TopicModel> filteredList;
        //        if (!string.IsNullOrEmpty(param.sSearch))
        //        {
        //            filteredList = TopicModel.Where(c => c.TopicName.ToLower().Contains(param.sSearch.ToLower()));
        //        }
        //        else
        //        {
        //            filteredList = TopicModel;
        //        }
        //        var sortColumnIndex = Convert.ToInt32(Request["iSortCol_0"]);
        //        Func<TopicModel, string> orderingFunction = (c => sortColumnIndex == 1 ? c.TopicName :
        //                                                            sortColumnIndex == 2 ? c.TopicName :
        //                                                            c.TopicName);

        //        var sortDirection = Request["sSortDir_0"]; // asc or desc
        //        if (sortDirection == "asc")
        //            filteredList = filteredList.OrderBy(orderingFunction);
        //        else
        //            filteredList = filteredList.OrderByDescending(orderingFunction);
        //        return Json(new
        //        {
        //            sEcho = param.sEcho,
        //            iTotalRecords = TopicModel.Count(),
        //            iTotalDisplayRecords = TopicModel.Count(),
        //            aaData = filteredList.Skip(param.iDisplayStart).Take(param.iDisplayLength) //paging
        //        }, JsonRequestBehavior.AllowGet);
        //    }

        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}
       
        //public virtual JsonResult IsTopicExist(int TopicId = 0, string nameOfTopic = "")
        //{
        //    bool isTopicExist = false;
        //    try
        //    {
        //        isTopicExist = iTopicBll.IsTopicExists(nameOfTopic);
        //        if (isTopicExist)
        //        {
        //            return Json("This TopicName already exists", JsonRequestBehavior.AllowGet);
        //        }

        //        return Json("Available", JsonRequestBehavior.AllowGet);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        //public virtual JsonResult IsTopicExistForEdit(int? TopicId = 0, string nameOfTopic = "")
        //{
        //    bool isTopicExistForEdit = false;
        //    try
        //    {
        //        isTopicExistForEdit = iTopicBll.IsTopicExistsForEdit((int)TopicId, nameOfTopic);
        //        if (isTopicExistForEdit)
        //        {
        //            return Json("This TopicName Already Exist", JsonRequestBehavior.AllowGet);
        //        }
        //        return Json("Available", JsonRequestBehavior.AllowGet);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        //public ActionResult AddEditTopic(int ID)
        //{

        //    TopicModel TopicModel = new TopicModel();
        //    TopicVM TopicVM = new TopicVM();

        //    if (ID != 0)
        //    {
        //        TopicModel = iTopicBll.GetTopicByTopicId(ID);

        //        AutoMapper.Mapper.Map(TopicModel, TopicVM);

        //        return PartialView("TopicUI", TopicVM);

        //    }
        //    return PartialView("TopicUI", TopicVM);
        //}

        //[HttpPost]
        //public JsonResult AddEditTopic(TopicVM TopicVM)
        //{
        //    try
        //    {
        //        TopicModel TopicModel = new TopicModel();
        //        AutoMapper.Mapper.Map(TopicVM, TopicModel);
        //        if (ModelState.IsValid)
        //        {
        //            if (SessionManagement.SessionID != null)
        //            {
        //                TopicModel.CreatedBy = TopicModel.UpdatedBy = SessionManagement.CurrentSession.AppUserID.ToString();
        //            }

                  
        //            TopicModel = iTopicBll.AddUpdateTopic(TopicModel);
        //            if (TopicModel.TopicId != 0)
        //            {
        //                TopicModel.Status = true;
        //            }
        //        }
        //        else
        //        {
        //            TopicModel.Status = false;
        //            ModelState.AddModelError("", "");

        //        }
        //        AutoMapper.Mapper.Map(TopicModel,TopicVM);
        //        return Json(TopicVM, JsonRequestBehavior.AllowGet);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}
        //public JsonResult Delete(int Id)
        //{

        //    bool status = false;

        //    status = iTopicBll.DeleteTopic(Id);

        //    return Json(status, JsonRequestBehavior.AllowGet);

        //}

    }
}