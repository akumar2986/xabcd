﻿using IndiaTutorial.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IndiaTutorial.Controllers
{
    public class TutorialController : Controller
    {
        //
        // GET: /Tutorial/

        public ActionResult Index()
        {
            return this.View(new QuestionModel { });
           // return View();
        }

        public ActionResult CSharp()
        {
            return View();
        }

        public ActionResult Page1()
        {
            return View();
        }

    }
}
