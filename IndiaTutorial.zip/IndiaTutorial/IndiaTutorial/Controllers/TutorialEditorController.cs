﻿using IndiaTutorial.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IndiaTutorial.Controllers
{
    public class TutorialEditorController : Controller
    {
        [HttpGet]
        public ActionResult Index()
        {
            Tutorial.BLL.TutorialTopic article = new Tutorial.BLL.TutorialTopic();
            List<Tutorial.Entities.TutorialTopic> articlentities = article.GetArticlesByArticleId(0);
            List<BaseViewModel> articlelist = new List<BaseViewModel>();
            foreach (var item in articlentities)
            {
                TutorialModel articlemodel = new TutorialModel();
                articlemodel.TopicId = item.TutorialId;
                articlemodel.TopicName = item.Name;
                articlemodel.TutorialModels = new List<TutorialModel>();
                foreach (var subarticle in item.TutorialTopics)
                {
                    TutorialModel model = new TutorialModel();
                    model.TopicId = subarticle.TutorialId;
                    model.TopicName = subarticle.Name;
                    articlemodel.TutorialModels.Add(model);
                }
                articlelist.Add(articlemodel);
            }
            return View(articlelist);
        }

        [HttpPost]
        public string CKEditor(string data)
        {
            string value = data;
            return value;
        }

        public ActionResult Question()
        {
            Tutorial.BLL.TutorialTopic article = new Tutorial.BLL.TutorialTopic();
            List<Tutorial.Entities.TutorialTopic> articlentities = article.GetArticlesByArticleId(0);
            List<BaseViewModel> articlelist = new List<BaseViewModel>();
            foreach (var item in articlentities)
            {
                TutorialModel articlemodel = new TutorialModel();
                articlemodel.TopicId = item.TutorialId;
                articlemodel.TopicName = item.Name;
                articlemodel.TutorialModels = new List<TutorialModel>();
                foreach (var subarticle in item.TutorialTopics)
                {
                    TutorialModel model = new TutorialModel();
                    model.TopicId = subarticle.TutorialId;
                    model.TopicName = subarticle.Name;
                    articlemodel.TutorialModels.Add(model);
                }
                articlelist.Add(articlemodel);
            }

            List<QuestionModel> questionmodel = new List<QuestionModel>();


            return View(articlelist);
        }


        public ActionResult MCQPartial(FormCollection collection)
        {
            return null;
        }
    }
}
