﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IndiaTutorial.Models
{
    public abstract class BaseViewModel
    {
        public int TopicId { get; set; }
        public string TopicName { get; set; }
        public List<TutorialModel> TutorialModels { get; set; }
    }
}