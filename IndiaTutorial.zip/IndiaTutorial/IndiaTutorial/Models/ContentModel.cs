﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IndiaTutorial.Models
{
    public class ContentModel
    {
        public int ContentId { get; set; }
        public string ContentData { get; set; }
    }
}