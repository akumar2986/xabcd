﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IndiaTutorial.Models
{
    public class QuestionModel:BaseViewModel
    {
        public long QuestionId { get; set; }
        public string Description { get; set; }
        public string CustomerCode { get; set; }
        public long QuestionTypeID { get; set; }
        public long TopicId { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public System.DateTime CreatedDateTime { get; set; }
        public System.DateTime ModifiedDateTime { get; set; }

        public List<QuestionOptionModel> QuestionOptionModels { get; set; }
    }

    public class QuestionOptionModel
    {
        public long OptionId { get; set; }
        public string OptionDesc { get; set; }
        public long QuestionId { get; set; }
    }
}