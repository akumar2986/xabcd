﻿/*Plugin Start*/
$(function () { ModalInitDialog(); });
var ModalPagingArray = [];
var ModalPagingData = [];

var ModalTwoPagingArray = [];
var ModalTwoPagingData = [];
var ModalThreePagingData = [];
var ModalThreePagingArray = [];
var ModalFourPagingData = [];
var ModalFourPagingArray = [];

var ModalPagingCurrentId;
var isUpdateNextBtn = false;
var ModalPlatform = "";
function ModalInitDialog(data) {
    // ModalAddPrevNextBtns();

    if (data != 0 && data != undefined) {
        $('#common_modal #modal_save_btn').val("Update").text("Update")
        ModalRemovePrevNextBtns();
        ModalAddPrevNextBtns();
    }
    else {
        $('#common_modal #modal_save_btn').val("Save").text("Save")
        ModalRemovePrevNextBtns();
    }
    $('#common_modal .close').click(function () { $('#common_modal #modal_msg').addClass('hide'); });
    $('#common_modal #modal_save_btn').off('click').on('click', function (e) { ModalBtnClicked($(this).attr('id'), -1); });
    $('#common_modal #modal_cancel_btn').off('click').on('click', function (e) { ModalBtnClicked($(this).attr('id'), -1); });
    $('#common_modal #modal_delete_btn').off('click').on('click', function (e) { ModalConfirmDelete(); });
    $("#common_confirm_delete #modal_confirm_delete_btn").off('click').on('click', function () { $('#common_confirm_delete').modal('toggle'); ModalBtnClicked('modal_delete_btn', -1); });
}
var ModalConfirmDelete = function () {
    $('#common_confirm_delete').modal({ show: 'true', backdrop: false });
    $('#common_modal').focus()
}
var ModalAddPrevNextBtns = function () {
    var prev = $('<a href="#" id="modal_prev_btn" class="hide btn btn-default  pull-left"><i class="fa fa-backward"></i> Prev</a>');
    $('#common_modal .modal-footer').prepend(prev);

    var updateNext = $('<a href="#" id="modal_upd_next_btn" class="btn btn-primary ">Update &amp; Next <i class="fa fa-forward"></i></a>');
    $('#common_modal .modal-footer #modal_save_btn').after(updateNext);

    var next = $('<a href="#" id="modal_next_btn" class="btn btn-default  pull-right">Next <i class="fa fa-forward"></i></a>');
    $('#common_modal .modal-footer').append(next);
}
var ModalRemovePrevNextBtns = function () {
    $("#modal_prev_btn").remove();
    $("#modal_upd_next_btn").remove();
    $("#modal_next_btn").remove();
}
var ModalShowMsg = function (alertType, alertHtm) {
    alertType = alertType.length > 0 ? alertType.toLowerCase() : 'info';
    $('#common_modal #modal_msg')
        .addClass('alert-' + alertType)
        .removeClass('hide')
        .find('#modal_msg_text')
        .html(alertHtm);
}


function ModalLoadDialogPaging(dataTableSelector, dataColumn) {

    //ModalPagingArray = $(arraySelector).map(function (i) { return $(this).attr('id') });
    ModalPagingData = $(dataTableSelector).DataTable().rows({ filter: 'applied', search: 'applied' }).data();
    ModalPagingArray = ModalPagingData.map(function (row) { return row[dataColumn]; });


    $(dataTableSelector)
        .off('order.dt, search.dt')
        .on('order.dt, search.dt', function () { ModalLoadDialogPaging(dataTableSelector, dataColumn); });
}

function ModalTwoLoadDialogPaging(dataTableSelector, dataColumn) {

    //ModalPagingArray = $(arraySelector).map(function (i) { return $(this).attr('id') });
    ModalTwoPagingData = $(dataTableSelector).DataTable().rows({ filter: 'applied', search: 'applied' }).data();
    ModalTwoPagingArray = ModalTwoPagingData.map(function (row) { return row[dataColumn]; });


    $(dataTableSelector)
        .off('order.dt, search.dt')
        .on('order.dt, search.dt', function () { ModalTwoLoadDialogPaging(dataTableSelector, dataColumn); });
}
function ModalThreeLoadDialogPaging(dataTableSelector, dataColumn) {

    //ModalPagingArray = $(arraySelector).map(function (i) { return $(this).attr('id') });
    ModalThreePagingData = $(dataTableSelector).DataTable().rows({ filter: 'applied', search: 'applied' }).data();
    ModalThreePagingArray = ModalThreePagingData.map(function (row) { return row[dataColumn]; });


    $(dataTableSelector)
        .off('order.dt, search.dt')
        .on('order.dt, search.dt', function () { ModalThreeLoadDialogPaging(dataTableSelector, dataColumn); });
}
function ModalFourLoadDialogPaging(dataTableSelector, dataColumn) {

    //ModalPagingArray = $(arraySelector).map(function (i) { return $(this).attr('id') });
    ModalFourPagingData = $(dataTableSelector).DataTable().rows({ filter: 'applied', search: 'applied' }).data();
    ModalFourPagingArray = ModalFourPagingData.map(function (row) { return row[dataColumn]; });


    $(dataTableSelector)
        .off('order.dt, search.dt')
        .on('order.dt, search.dt', function () { ModalFourLoadDialogPaging(dataTableSelector, dataColumn); });
}
function ModalShowDialog(currentId, modalContentUrl) {
    ModalPagingCurrentId = currentId;
    $('#common_modal #modal_msg').addClass('hide');
    $('#common_modal #modal_content_div').load(modalContentUrl, function () {
        ModalShowPrevNextBtns();
        $('#common_modal').modal('show');
    });
    return true;
}

var ModalBtnClicked = function (btn_id, pagingGotoId, dataRow) { }

var ModalShowPrevNextBtns = function () {

    $.each(ModalPagingArray, function (index, value) {
        if (ModalPagingCurrentId == value) {
            //if (typeof modal_save_btn_text != undefined) $('#common_modal #modal_save_btn').val(modal_save_btn_text).text(modal_save_btn_text);

            if (index > 0) {
                $('#common_modal #modal_prev_btn').removeClass('hide').off('click').on('click', function (e) { ModalBtnClicked($(this).attr('id'), ModalPagingArray[index - 1], ModalPagingData[index - 1]); });
            } else { $('#common_modal #modal_prev_btn').addClass('hide'); }

            if ((index + 1) != ModalPagingArray.length) {
                $('#common_modal #modal_upd_next_btn').removeClass('hide').off('click').on('click', function (e) { ModalBtnClicked($(this).attr('id'), ModalPagingArray[index + 1], ModalPagingData[index + 1]); });
                $('#common_modal #modal_next_btn').removeClass('hide').off('click').on('click', function (e) { ModalBtnClicked($(this).attr('id'), ModalPagingArray[index + 1], ModalPagingData[index + 1]); });
            } else { $('#common_modal #modal_upd_next_btn, #common_modal #modal_next_btn').addClass('hide'); }
        }


    });
    $.each(ModalTwoPagingArray, function (index, value) {
        if (ModalPagingCurrentId == value) {
            //if (typeof modal_save_btn_text != undefined) $('#common_modal #modal_save_btn').val(modal_save_btn_text).text(modal_save_btn_text);

            if (index > 0) {
                $('#common_modal #modal_prev_btn').removeClass('hide').off('click').on('click', function (e) { ModalBtnClicked($(this).attr('id'), ModalTwoPagingArray[index - 1], ModalTwoPagingData[index - 1]); });
            } else { $('#common_modal #modal_prev_btn').addClass('hide'); }

            if ((index + 1) != ModalTwoPagingArray.length) {
                $('#common_modal #modal_upd_next_btn').removeClass('hide').off('click').on('click', function (e) { ModalBtnClicked($(this).attr('id'), ModalTwoPagingArray[index + 1], ModalTwoPagingData[index + 1]); });
                $('#common_modal #modal_next_btn').removeClass('hide').off('click').on('click', function (e) { ModalBtnClicked($(this).attr('id'), ModalTwoPagingArray[index + 1], ModalTwoPagingData[index + 1]); });
            } else { $('#common_modal #modal_upd_next_btn, #common_modal #modal_next_btn').addClass('hide'); }
        }


    });
    $.each(ModalThreePagingArray, function (index, value) {
        if (ModalPagingCurrentId == value) {
            //if (typeof modal_save_btn_text != undefined) $('#common_modal #modal_save_btn').val(modal_save_btn_text).text(modal_save_btn_text);

            if (index > 0) {
                $('#common_modal #modal_prev_btn').removeClass('hide').off('click').on('click', function (e) { ModalBtnClicked($(this).attr('id'), ModalThreePagingArray[index - 1], ModalThreePagingData[index - 1]); });
            } else { $('#common_modal #modal_prev_btn').addClass('hide'); }

            if ((index + 1) != ModalThreePagingArray.length) {
                $('#common_modal #modal_upd_next_btn').removeClass('hide').off('click').on('click', function (e) { ModalBtnClicked($(this).attr('id'), ModalThreePagingArray[index + 1], ModalThreePagingData[index + 1]); });
                $('#common_modal #modal_next_btn').removeClass('hide').off('click').on('click', function (e) { ModalBtnClicked($(this).attr('id'), ModalThreePagingArray[index + 1], ModalThreePagingData[index + 1]); });
            } else { $('#common_modal #modal_upd_next_btn, #common_modal #modal_next_btn').addClass('hide'); }
        }


    });
    $.each(ModalFourPagingArray, function (index, value) {
        if (ModalPagingCurrentId == value) {
            //if (typeof modal_save_btn_text != undefined) $('#common_modal #modal_save_btn').val(modal_save_btn_text).text(modal_save_btn_text);

            if (index > 0) {
                $('#common_modal #modal_prev_btn').removeClass('hide').off('click').on('click', function (e) { ModalBtnClicked($(this).attr('id'), ModalFourPagingArray[index - 1], ModalFourPagingData[index - 1]); });
            } else { $('#common_modal #modal_prev_btn').addClass('hide'); }

            if ((index + 1) != ModalFourPagingArray.length) {
                $('#common_modal #modal_upd_next_btn').removeClass('hide').off('click').on('click', function (e) { ModalBtnClicked($(this).attr('id'), ModalFourPagingArray[index + 1], ModalFourPagingData[index + 1]); });
                $('#common_modal #modal_next_btn').removeClass('hide').off('click').on('click', function (e) { ModalBtnClicked($(this).attr('id'), ModalFourPagingArray[index + 1], ModalFourPagingData[index + 1]); });
            } else { $('#common_modal #modal_upd_next_btn, #common_modal #modal_next_btn').addClass('hide'); }
        }


    });
}

$('#common_modal').on('hidden.bs.modal', function () {
    ModalBtnClicked('modal_close', 0);
});
$('#common_modal form').submit(function (e) {
    e.preventdefault();
    $('#common_modal modal_save_btn').click();
});
// handler for multiple modal--
$('.modal').on("hidden.bs.modal", function (e) { //fire on closing modal box
    if ($('.modal:visible').length) {
        $('body').addClass('modal-open');
    }
});
// multiple Save functionality 

var SaveRecordData = function (formId, url, formData, contentType) {
    var form = $("#" + formId);
    try {
        var validator = form.validate(); if (!form.valid()) {
            $(".errormsgspan").show();
            return false;
        }
        else {
            $(".errorSummary").hide();
        }
    }
    catch (ex) { }

    if (url != null) // this condition is used for DataProvider Case
    {
        $.ajax({
            url: url,
            type: "POST",
            contentType: (contentType == null ? 'application/x-www-form-urlencoded; charset=UTF-8' : false),
            data: formData,
            dataType: "json",
            processData: false,
            success: function (response) {
                // 

                if (response.Errors != null && response.Errors != "") {
                    $(".dateErrorClasss").text(null);
                    $.each(response.Errors, function (key, value) {
                        $(".dateErrorClasss").append('<li>' + value + '</li>');
                    });
                }
                else {
                    setUniqueIdForUpdate(response);
                    $(".dateErrorClasss").text("");
                    if (response.Status == true) {
                        ModalShowMsg("success", "Data Successfully Saved!");
                        form[0].reset();
                        if (isUpdateNextBtn == true) { goToNextPage(); }

                    }
                    else {
                        if (response.AdBookTypeId != undefined && response.AdBookTypeId != 0) { ModalShowMsg("danger", "This booktype is not allowed for this merchant !"); }
                        else { ModalShowMsg("danger", "Something happen Wrong!"); }

                    }
                }

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                ModalShowMsg("danger", XMLHttpRequest.responseText);
                refreshDataTableRequired = true;
            }
        });
    }
    else {


    }
}


var DeleteRecord = function (url, data, contentType) {
    $.ajax({
        url: url + data,
        type: "POST",
        // contentType: (contentType == null ? 'application/x-www-form-urlencoded; charset=UTF-8' : false),
        dataType: "json",
        processData: false,
        success: function (response) {
            if (response == true) {
                ModalShowMsg("success", "Data Successfully Deleted!");
                refreshDataTable();
            }
            else
            {
                ModalShowMsg("danger", "Please firstly delete attribute group on attribute group mapping screen !");
                refreshDataTable();
            }

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            ModalShowMsg("danger", XMLHttpRequest.responseText);
            // refreshDataTableRequired = true;
        }
    });

}











