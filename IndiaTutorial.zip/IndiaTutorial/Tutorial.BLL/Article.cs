﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tutorial.DAL;

namespace Tutorial.BLL
{
    public class TutorialTopic
    {
        public List<Tutorial.Entities.TutorialTopic> GetArticlesByArticleId(int articleId)
        {
            TutorialDAL dal=new TutorialDAL();
            DataSet ds = dal.GetTopicsByTopicId(articleId);

            var groupedData = (from b in ds.Tables[0].AsEnumerable()
                               group b by
                               new
                                   {
                                       ID = b.Field<int>("TopicId"),
                                       Name = b.Field<string>("Name")
                                   }
                                   into g
                                   select new
                                   {
                                       ArticleId = g.Key.ID,
                                       ArticleName = g.Key.Name,
                                       List = g
                                   });
            var articles = new List<Tutorial.Entities.TutorialTopic>();


            foreach (var item in groupedData)
            {
                Tutorial.Entities.TutorialTopic articleobj = new Tutorial.Entities.TutorialTopic();
                articleobj.TutorialId = item.ArticleId;
                articleobj.Name = item.ArticleName;             
                articleobj.TutorialTopics = new List<Entities.TutorialTopic>();
                foreach (var item2 in item.List)
                {
                    articleobj.TutorialTopics.Add(new Entities.TutorialTopic()
                    {
                        TutorialId = Convert.ToInt32(item2["TopicId"]),
                        Name = Convert.ToString(item2["TopicName"]),
                    });
                }

                articles.Add(articleobj);
            }
            return articles;
        }
    }
}
