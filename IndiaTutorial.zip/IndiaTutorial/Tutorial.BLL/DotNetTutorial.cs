﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tutorial.DAL;

namespace Tutorial.BLL
{
    public class DotNetTutorial
    {
        //public ContentText GetContentText(int id)
        //{
        //    using (IndianTutorialEntities dbcontext = new IndianTutorialEntities())
        //    {
        //        ContentText content = dbcontext.ContentTexts.FirstOrDefault(i => i.ContentId==id);
        //        return content;
        //    }
        //}


    }
}
