﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tutorial.DAL;

namespace Tutorial.BLL
{
    public class Question
    {
        public List<Tutorial.Entities.Question> GetQuestionsByTopicId(int topicid)
        {
            TutorialDAL dal = new TutorialDAL();
            DataSet ds = dal.GetQuestionsByTopicId(topicid);

            var questionsdata = (from b in ds.Tables[0].AsEnumerable()
                                 group b by
                                 new
                                 {
                                     ID = b.Field<int>("QuestionId")
                                 }
                                     into g
                                     select new
                                     {
                                         QuestionId = g.Key.ID,
                                         List = g
                                     });
            var questions = new List<Tutorial.Entities.Question>();


            foreach (var item in questionsdata)
            {
                Tutorial.Entities.Question quest = new Tutorial.Entities.Question();
                quest.QuestionId = item.QuestionId;
               
                quest.QuestOptions = new List<Entities.QuestOption>();
                foreach (var item2 in item.List)
                {
                    quest.QuestOptions.Add(new Entities.QuestOption()
                    {
                        OptionId = Convert.ToInt32(item2["OptionId"]),
                        OptionDesc = Convert.ToString(item2["OptionDesc"]),
                    });
                }

                questions.Add(quest);
            }
            return questions;
        }

        //public List<ArticleObject> GetBGDetailsByUserStatus(int bgStatusID, int roleID)
        //{
        //    var DBContext = new IndianTutorialEntities(GlobalClass.ConnectionString);
        //    try
        //    {
        //        List<Question> result = DBContext.spGetBGDetailByBGStatus(bgStatusID, roleID, SessionManager.Current.ProfitCenterID).ToList();
        //        return result.ToList();
        //    }
        //    finally
        //    {
        //        DBContext.Dispose();
        //    }
        //}

        //public string SaveQuestions(QuestionObject question)
        //{
        //    var DBContext = new IndianTutorialEntities(GlobalClass.ConnectionString);
        //    try
        //    {
        //        return null;
        //    }
        //    finally
        //    {
        //        DBContext.Dispose();
        //    }
        //}

      

        //public List<Question> GetQuestions(long questionid)
        //{
        //    var DBContext = new IndianTutorialEntities(GlobalClass.ConnectionString);
        //    try
        //    {
        //        var customers = (from e in DBContext.spGetCustomerByProjectID(projectID)
        //                         select new CustomerObject()
        //                         {
        //                             CustomerID = e.CustomerID,
        //                             CustomerName = e.customerName
        //                         });

        //        List<CustomerObject> data = customers.ToList();

        //        return data;
        //    }
        //    finally
        //    {
        //        DBContext.Dispose();
        //    }
        //}
     

    }
}
