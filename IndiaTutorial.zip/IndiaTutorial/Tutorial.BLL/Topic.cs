﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tutorial.DAL;

namespace Tutorial.BLL
{
    public class Topic
    {
        public List<Tutorial.Entities.TutorialTopic> GetTopics()
        {
            TutorialDAL _dal = new TutorialDAL();
            DataSet ds = _dal.GetTopicsByTopicId(0);
            return null;
        }

        public List<Tutorial.Entities.Question> GetQuestionsByTopicId(int topicid)
        {
            TutorialDAL dal = new TutorialDAL();
            DataSet ds = dal.GetQuestionsByTopicId(topicid);

            var questionsdata = (from b in ds.Tables[0].AsEnumerable()
                                 group b by
                                 new
                                 {
                                     ID = b.Field<int>("QuestionId")
                                 }
                                     into g
                                     select new
                                     {
                                         QuestionId = g.Key.ID,
                                         List = g
                                     });
            var questions = new List<Tutorial.Entities.Question>();


            foreach (var item in questionsdata)
            {
                Tutorial.Entities.Question quest = new Tutorial.Entities.Question();
                quest.QuestionId = item.QuestionId;

                quest.QuestOptions = new List<Entities.QuestOption>();
                foreach (var item2 in item.List)
                {
                    quest.QuestOptions.Add(new Entities.QuestOption()
                    {
                        OptionId = Convert.ToInt32(item2["OptionId"]),
                        OptionDesc = Convert.ToString(item2["OptionDesc"]),
                    });
                }

                questions.Add(quest);
            }
            return questions;
        }
    }
}
