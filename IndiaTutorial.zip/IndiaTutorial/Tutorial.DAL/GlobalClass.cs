﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tutorial.DAL
{
    public class GlobalClass
    {
        public static string ConnectionString
        {
            get
            {
                return ConfigurationManager.ConnectionStrings["IndianTutorialEntities"].ConnectionString;
            }
        }

        public static string ConnString
        {
            get
            {
                return ConfigurationManager.ConnectionStrings["ImportExportSQL"].ConnectionString;
            }
        }

        private static IndianTutorialEntities _dBContext;
        public static IndianTutorialEntities DBContext
        {
            get
            {
                if (_dBContext == null)
                {
                    _dBContext = new IndianTutorialEntities();
                }
                return _dBContext;
            }
            set
            {
                _dBContext = value;
            }
        }

       
        
    }
}
