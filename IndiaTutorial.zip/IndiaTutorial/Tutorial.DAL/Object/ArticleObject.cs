﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tutorial.DAL
{
    public class ArticleObject
    {
        public int ArticleId { get; set; }
        public string ArticleName { get; set; }

        public int TotalSubArticles { get; set; }
        public List<ArticleObject> ArticleObjects { get; set; }
    }
}
