﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tutorial.DAL
{
    public class QuestionObject
    {
        public long QuestionId { get; set; }
        public string Description { get; set; }
        public string CustomerCode { get; set; }
        public long QuestionTypeID { get; set; }
        public long ArticleID { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public System.DateTime CreatedDateTime { get; set; }
        public System.DateTime ModifiedDateTime { get; set; }

        public List<QuestionOptionObject> QuestionOptionsObject { get; set; }
    }

    public class QuestionOptionObject
    {
        public long OptionId { get; set; }
        public string OptionDesc { get; set; }

        public long QuestionId { get; set; }
    }
   
}
