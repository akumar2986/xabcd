using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Collections;

namespace Tutorial.DAl
{
    public class DBAccess
    {
        #region PROPERTIES
        private SqlConnection Connection { get; set; }
        public string Query { get; set; }
        private SqlCommand Command { get; set; }
        public List<SqlParameter> Parameters { get; set; }
        public bool UseTransaction { get; set; }
        private SqlTransaction Transaction { get; set; }
        private string ConnectionString { get; set; }

        #endregion

        #region CONSTRUCTOR
        public DBAccess()
        {
            string _connectionString = GetConnectionString();
            this.Connection = new SqlConnection(_connectionString);
            this.Query = string.Empty;
            this.Parameters = new List<SqlParameter>();
            this.UseTransaction = false;
            this.ConnectionString = "Data Source=UTKARSH\\SQLSERVER; Initial Catalog=IndianTutorial; Integrated Security=false;User ID=sa;Password=sa$123;Connect Timeout=2000;";
        }
        #endregion

        public string GetConnectionString()
        {
            return ConnectionString;
        }

        public SqlConnection GetConnection()
        {
            string _connectionString = GetConnectionString();
            return new SqlConnection(_connectionString);
        }

        private void ValidateCommit(ref DBAccess _dba)
        {
            if (_dba.Command.Transaction != null)
            {
                _dba.Command.Transaction.Commit();
            }
        }

        private void ValidateRollback(ref DBAccess _dba)
        {
            if (_dba.Command.Transaction != null)
            {
                _dba.Command.Transaction.Rollback();
            }
        }

        private void DisposeConnection(ref DBAccess _dba)
        {
            _dba.Connection.Close();
            _dba.Command.Dispose();
            _dba.Connection.Dispose();
        }

        private DBAccess DecideCommandType(DBAccess _dba)
        {
            if (_dba.Parameters.Count.Equals(0))
            {
                _dba.Command.CommandType = CommandType.Text;
            }
            else
            {
                _dba.Command.CommandType = CommandType.StoredProcedure;
                for (int _counter = 0; _counter < _dba.Parameters.Count; _counter++)
                {
                    _dba.Command.Parameters.Add(_dba.Parameters[_counter]);
                }
            }
            return _dba;
        }

        private DBAccess Format(DBAccess _dba)
        {
            _dba.Connection = GetConnection();
            _dba.Connection.Open();
            if (_dba.UseTransaction.Equals(true))
            {
                _dba.Transaction = Connection.BeginTransaction();
                _dba.Command = new SqlCommand(_dba.Query, Connection, Transaction);
            }
            else
            {
                _dba.Command = new SqlCommand(_dba.Query, Connection);
            }
            _dba = DecideCommandType(_dba);
            return _dba;
        }

        public SqlDataReader ExecuteReader(DBAccess _dba)
        {
            _dba = Format(_dba);
            SqlDataReader _reader;
            try
            {
                _reader = _dba.Command.ExecuteReader(CommandBehavior.CloseConnection);
                ValidateCommit(ref _dba);
            }
            catch (Exception ex)
            {
                ValidateRollback(ref _dba);
                DisposeConnection(ref _dba);

                throw ex;
            }
            return _reader;
        }

        public object ExecuteNonQuery(DBAccess _dba)
        {
            _dba = Format(_dba);
            object _result = new object();
            try
            {
                _result = _dba.Command.ExecuteNonQuery();
                SqlParameter _para = null;
                _para = Parameters.Find(x => x.Direction.Equals(ParameterDirection.ReturnValue));
                if (_para != null)
                {
                    _result = _para.Value;
                }

                ValidateCommit(ref _dba);

            }
            catch (Exception ex)
            {
                ValidateRollback(ref _dba);
                throw ex;
            }
            finally
            {
                DisposeConnection(ref _dba);
            }
            return _result;
        }

        public DataSet ExecuteDataSet(DBAccess _dba)
        {
            _dba = Format(_dba);
            DataSet _ds = new DataSet();
            try
            {
                SqlDataAdapter _da = new SqlDataAdapter(_dba.Command);
                _da.Fill(_ds);
                ValidateCommit(ref _dba);
            }
            catch (Exception ex)
            {
                ValidateRollback(ref _dba);
                throw ex;
            }
            finally
            {
                DisposeConnection(ref _dba);
            }
            return _ds;
        }

        public DataTable ExecuteDataTable(DBAccess _dba)
        {
            _dba = Format(_dba);
            DataTable _dt = new DataTable();
            try
            {
                SqlDataAdapter _da = new SqlDataAdapter(_dba.Command);
                _da.Fill(_dt);
                ValidateCommit(ref _dba);
            }
            catch (Exception ex)
            {
                ValidateRollback(ref _dba);
                throw ex;
            }
            finally
            {
                DisposeConnection(ref _dba);
            }
            return _dt;
        }

        public object ExecuteScalar(DBAccess _dba)
        {
            _dba = Format(_dba);
            object _result = new object();
            try
            {
                _result = _dba.Command.ExecuteScalar();
                ValidateCommit(ref _dba);
            }
            catch (Exception ex)
            {
                ValidateRollback(ref _dba);
                throw ex;
            }
            finally
            {
                DisposeConnection(ref _dba);
            }
            return _result;
        }
    }
}
