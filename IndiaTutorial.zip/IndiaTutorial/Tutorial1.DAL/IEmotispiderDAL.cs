﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace EmotiWCF_DAL
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    //[ServiceContract]
    //public interface IEmotispiderDAL
    //{
    //    [OperationContract]
    //    DataSet GetAddAndGetHeatmap(HeatmapDTO heatmapDTO);

    //    [OperationContract]
    //    void UpdateProjectImageURL(HeatmapDTO heatmapDTO);


    //    [OperationContract]
    //    DataSet GetHeatmapData(int _projectId);



    //    [OperationContract]                                                     //for getting the History Log 
    //    //DataSet GetHistoryLog(HeatmapDTO heatmapDTO);
    //    DataSet getdetails();

    //    [OperationContract]                                                     // used for filtering of FromDate, ToDate, ProjectName
    //    DataSet getdetailsfilter(DateTime FromDate, DateTime ToDate, string ProjectName);

    //    [OperationContract]               
    //    DataSet getdetailsdays(String ProjectDays);                              // used for filtering of 30 Days, 60 Days, 90 Days


    //    [OperationContract]
    //    DataSet GetHistoryLogByProjectKey(HeatmapDTO heatmapDTO);               //used for displaying logs on the basis of ProjectKey

    //}
}
