﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using Tutorial.DAl;

namespace Tutorial.DAL
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    public class TutorialDAL 
    {

        public DataSet GetTopicsByTopicId(int articleId)
        {
            DataSet ds = new DataSet();
            DBAccess _dbAccess = new DBAccess();
            _dbAccess.Query = "spGetTopicsByTopicId";
            _dbAccess.Parameters.Add(new SqlParameter { ParameterName = "topicid", Value = articleId });
            ds = _dbAccess.ExecuteDataSet(_dbAccess);
            return ds;
        }

        public DataSet GetQuestionsByTopicId(int topicId)
        {
            DataSet ds = new DataSet();
            DBAccess _dbAccess = new DBAccess();
            _dbAccess.Query = "spGetQuestionsByTopicId";
            _dbAccess.Parameters.Add(new SqlParameter { ParameterName = "topicId", Value = topicId });
            ds = _dbAccess.ExecuteDataSet(_dbAccess);
            return ds;
        }
        
        //public void UpdateProjectImageURL(HeatmapDTO heatmapDTO)
        //{
        //    DBAccess _dbAccess = new DBAccess();
        //    _dbAccess.Query = "sp_updateProjectURL";
        //    _dbAccess.Parameters.Add(new SqlParameter { ParameterName = "para_projectId", Value = heatmapDTO.projectId });
        //    _dbAccess.Parameters.Add(new SqlParameter { ParameterName = "para_URL", Value = heatmapDTO.projectURL });
        //    _dbAccess.ExecuteNonQuery(_dbAccess);
        //}

        //public DataSet GetHeatmapData(int _projectId)
        //{
        //    DataSet ds = new DataSet();
        //    DBAccess _dbAccess = new DBAccess();
        //    _dbAccess.Query = "sp_getHeatmapDataByProjectId";
        //    _dbAccess.Parameters.Add(new SqlParameter { ParameterName = "para_projectId", Value = _projectId });
        //    ds = _dbAccess.ExecuteDataSet(_dbAccess);
        //    return ds;
        //}

        ////For history logs
        //public DataSet GetHistoryLog(HeatmapDTO heatmapDTO)         // for displaying all projects
        //{
        //    DataSet ds = new DataSet();
        //    DBAccess _dbAccess = new DBAccess();
        //    _dbAccess.Query = "sp_GetHistory";
        //    ds = _dbAccess.ExecuteDataSet(_dbAccess);
        //    return ds;
        //}

        //for binding ProjectKey
        //public DataSet getprojectkey()
        //{
        //    DataSet ds = new DataSet();
        //    DBAccess _dbAccess = new DBAccess();
        //    _dbAccess.Query = "sp_GetProjectKey";
        //    ds = _dbAccess.ExecuteDataSet(_dbAccess);
        //    return ds;
        //}

        ////for dispalying grid on the basis of ProjectKey Selection
        //public DataSet GetHistoryLogByProjectKey(HeatmapDTO heatmapDTO)
        //{
        //    DataSet ds = new DataSet();
        //    DBAccess _dbAccess = new DBAccess();
        //    _dbAccess.Query = "sp_GetHistoryByProjectKey";
        //    _dbAccess.Parameters.Add(new SqlParameter { ParameterName = "ProjectKey", Value = heatmapDTO.ProjectKey });
        //    ds = _dbAccess.ExecuteDataSet(_dbAccess);
        //    return ds;
        //}

        //public DataSet getdetailsfilter(DateTime FromDate, DateTime ToDate, string ProjectName)
        //{
        //    DataSet ds = new DataSet();
        //    DBAccess _dbAccess = new DBAccess();
        //    _dbAccess.Query = "sp_GetHistoryByFilter";
        //    _dbAccess.Parameters.Add(new SqlParameter { ParameterName = "fromdate", Value = FromDate });
        //    _dbAccess.Parameters.Add(new SqlParameter { ParameterName = "todate", Value = ToDate });
        //    _dbAccess.Parameters.Add(new SqlParameter { ParameterName = "projectname", Value = ProjectName });
        //    ds = _dbAccess.ExecuteDataSet(_dbAccess);
        //    return ds;
        //}

        //public DataSet getdetails()
        //{
        //    TutorialDAL _dal = new TutorialDAL();
        //    DataSet ds = new DataSet();
        //    HeatmapDTO heatmapDTO = new HeatmapDTO();
        //    ds = _dal.GetHistoryLog(heatmapDTO);
        //    return ds;
        //}
        
        //public DataSet getdetailsdays(string ProjectDays)      //will take parameter in days like 30, 60, 90 days and than we calculate FromDate and ToDate
        //{
        //    DataSet ds = new DataSet();
        //    DBAccess _dbAccess = new DBAccess();
        //    _dbAccess.Query = "sp_GetHistoryByDays";
        //    int days = Convert.ToInt32(ProjectDays);
        //    DateTime ToDate = System.DateTime.Now;
        //    DateTime FromDate = ToDate.AddDays(-days);
        //    _dbAccess.Parameters.Add(new SqlParameter { ParameterName = "ProjectDays", Value =ProjectDays });
        //    ds = _dbAccess.ExecuteDataSet(_dbAccess);
        //    return ds;
        //}
    }
}